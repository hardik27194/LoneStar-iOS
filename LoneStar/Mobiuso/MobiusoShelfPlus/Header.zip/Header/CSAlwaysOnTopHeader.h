//
//  CSAlwaysOnTopHeader.h
//
//

#import "CSCell.h"

@interface CSAlwaysOnTopHeader : CSCell

+ (NSString *)kind;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

@end
