//
//  CSAlwaysOnTopHeader.m
//  CSStickyHeaderFlowLayoutDemo
//
//

#import "CSAlwaysOnTopHeader.h"
#import "CSStickyHeaderFlowLayoutAttributes.h"

@implementation CSAlwaysOnTopHeader

NSString *kTopHeaderKind = @"ModuleTypeHeaderTop";

- (void)applyLayoutAttributes:(CSStickyHeaderFlowLayoutAttributes *)layoutAttributes {

    [UIView beginAnimations:@"" context:nil];

    if (layoutAttributes.progressiveness <= 0.58) {
        self.titleLabel.alpha = 1;
    } else {
        self.titleLabel.alpha = 0;
    }

    if (layoutAttributes.progressiveness >= 0.9) {  // Was 1
        self.searchBar.alpha = 1;
    } else {
        self.searchBar.alpha = 0;
    }

    [UIView commitAnimations];
}


+ (NSString *)kind
{
    return (NSString *)kTopHeaderKind;
}

@end
